# ========== main.py ==========
from voice_rec import transcribir_audio
from dialog_manager import actualizar_perfil, verificar_slots, obtener_estado_perfil, reiniciar_perfil
from guardar_datos import guardar_perfil_en_csv
from crm_api import enviar_lead
from preferencias import cargar_preferencias, guardar_preferencias
import pyttsx3

# -----------------------------
def decir(texto):
    engine = pyttsx3.init()
    engine.setProperty("rate", 160)
    engine.setProperty("volume", 1.0)
    engine.say(texto)
    engine.runAndWait()

def seleccionar_modo_entrada():
    print("🛠️ Elige el modo de interacción:")
    print("1. Voz 🎤")
    print("2. Texto ⌨️")
    while True:
        opcion = input("Selecciona 1 o 2: ")
        if opcion == "1":
            return "voz"
        elif opcion == "2":
            return "texto"
        else:
            print("❌ Opción no válida. Intenta nuevamente.")

# -----------------------------
def conversacion_por_voz():
    print("\n🤖 ¡Bienvenido! Empecemos.\n")

    preferencias_usuario = {}
    modo = seleccionar_modo_entrada()

    while True:
        while True:
            slot_actual, pregunta = verificar_slots()
            if not slot_actual:
                break

            print(f"🤖 {pregunta}")
            decir(pregunta)

            if slot_actual == "nombre":
                if modo == "voz":
                    texto_usuario = transcribir_audio()
                else:
                    texto_usuario = input("🧑 Tú (texto): ")

                actualizar_perfil(texto_usuario, slot_actual)

                # Buscar preferencias del usuario
                nombre = obtener_estado_perfil()["nombre"]
                preferencias_usuario = cargar_preferencias(nombre)
                if preferencias_usuario:
                    print(f"🎯 Preferencias encontradas para {nombre}: {preferencias_usuario}")
                    modo = preferencias_usuario.get("modo", modo)
                else:
                    print(f"ℹ️ No se encontraron preferencias previas para {nombre}")
            else:
                if modo == "voz":
                    texto_usuario = transcribir_audio()
                else:
                    texto_usuario = input("🧑 Tú (texto): ")

                if texto_usuario:
                    if "reiniciar" in texto_usuario.lower() or "empezar de nuevo" in texto_usuario.lower():
                        reiniciar_perfil()
                        print("🔄 Conversación reiniciada. Puedes comenzar de nuevo.")
                        break
                    elif "salir" in texto_usuario.lower() or "terminar" in texto_usuario.lower():
                        print("👋 Gracias por conversar. ¡Hasta luego!")
                        return

                    actualizar_perfil(texto_usuario, slot_actual)
                else:
                    print("⚠️ Entrada inválida o no entendida.")

        # Finalización
        perfil = obtener_estado_perfil()
        print("\n✅ Todos los datos han sido recopilados.")
        print(f"📊 Perfil del usuario: {perfil}")

        guardar_perfil_en_csv(perfil)
        enviar_lead(perfil)

        # Guardar preferencias del usuario
        preferencias_usuario["modo"] = modo
        preferencias_usuario.setdefault("historial", []).append(perfil.get("intencion", ""))
        guardar_preferencias(perfil["nombre"], preferencias_usuario)
        print("🧠 Preferencias del usuario guardadas.")
        break

if __name__ == "__main__":
    conversacion_por_voz()





