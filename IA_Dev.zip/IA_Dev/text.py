# ========== text.py ==========
from transformers import pipeline
import re

# Modelo NER en español
entidades = pipeline("ner", model="mrm8488/bert-spanish-cased-finetuned-ner", grouped_entities=True)

def extraer_nombre(texto):
    resultado_ner = entidades(texto)
    for entidad in resultado_ner:
        if entidad["entity_group"] == "PER":
            return entidad["word"]
    return None

def extraer_empresa(texto):
    resultado_ner = entidades(texto)
    for entidad in resultado_ner:
        if entidad["entity_group"] == "ORG":
            return entidad["word"]

    frases = [
        "trabajo en", "represento a", "soy de", "vengo de", "mi empresa es",
        "pertenezco a", "laboro en", "colaboro con", "somos", "somos parte de",
        "estoy en", "trabajamos en", "trabajo para", "representamos a"
    ]
    for frase in frases:
        if frase in texto.lower():
            resto = texto.lower().split(frase)[-1].strip()
            palabras = resto.split(" ")[:5]
            return " ".join(palabras).strip(",.")
    return None

def extraer_presupuesto(texto):
    resultado_ner = entidades(texto)
    for entidad in resultado_ner:
        if entidad["entity_group"] in ["MISC", "NUM"]:
            if entidad["word"].replace(",", "").replace("$", "").isdigit():
                return entidad["word"]

    match = re.search(r"(?:\$|USD\s?)?(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)", texto)
    if match:
        return match.group(1)
    return None

def extraer_intencion(texto):
    texto = texto.lower()
    if any(frase in texto for frase in ["quiero comprar", "me interesa", "estoy interesado", "necesito", "quiero contratar"]):
        return "interes"
    elif any(frase in texto for frase in ["quiero saber", "me puedes decir", "tengo dudas", "quisiera información"]):
        return "informacion"
    elif any(frase in texto for frase in ["cuál es mejor", "compara", "diferencia entre", "qué diferencia hay"]):
        return "comparacion"
    else:
        return "otro"

