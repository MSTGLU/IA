# ========== preferencias.py ==========
import json
import os

ARCHIVO_PREF = "usuarios.json"

def cargar_preferencias(nombre):
    if not os.path.exists(ARCHIVO_PREF):
        return {}
    with open(ARCHIVO_PREF, "r", encoding="utf-8") as f:
        prefs = json.load(f)
    return prefs.get(nombre, {})

def guardar_preferencias(nombre, preferencias):
    if os.path.exists(ARCHIVO_PREF):
        with open(ARCHIVO_PREF, "r", encoding="utf-8") as f:
            prefs = json.load(f)
    else:
        prefs = {}

    prefs[nombre] = preferencias

    with open(ARCHIVO_PREF, "w", encoding="utf-8") as f:
        json.dump(prefs, f, indent=2, ensure_ascii=False)
