# ========== guardar_datos.py ==========
import csv
import os

ARCHIVO_CSV = "leads.csv"
COLUMNAS = ["usuario_id", "nombre", "empresa", "necesidad", "presupuesto", "intencion"]

def guardar_perfil_en_csv(perfil):
    # Verifica si el archivo ya existe
    archivo_existe = os.path.isfile(ARCHIVO_CSV)

    # Obtener próximo ID
    usuario_id = 1
    if archivo_existe:
        with open(ARCHIVO_CSV, mode="r", newline="", encoding="utf-8") as f:
            reader = csv.reader(f)
            next(reader)  # saltar encabezado
            filas = list(reader)
            if filas:
                usuario_id = int(filas[-1][0]) + 1

    # Abrir en modo append
    with open(ARCHIVO_CSV, mode="a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=COLUMNAS)
        if not archivo_existe:
            writer.writeheader()
        fila = {
            "usuario_id": usuario_id,
            "nombre": perfil.get("nombre", ""),
            "empresa": perfil.get("empresa", ""),
            "necesidad": perfil.get("necesidad", ""),
            "presupuesto": perfil.get("presupuesto", ""),
            "intencion": perfil.get("intencion", "")
        }
        writer.writerow(fila)
