# ========== crm_api.py ==========
import requests

# CONFIGURACIÓN (ajústalo según tu CRM)
CRM_API_BASE_URL = "https://api.tu-crm.com"  # ej: https://api.hubapi.com
API_TOKEN = "TU_TOKEN_O_API_KEY"
HEADERS = {
    "Authorization": f"Bearer {API_TOKEN}",  # o "API-Key": "TU_CLAVE"
    "Content-Type": "application/json"
}

# ===============================
# Enviar nuevo lead (crear)
# ===============================
def enviar_lead(perfil):
    url = f"{CRM_API_BASE_URL}/leads"  # Cambiar por el endpoint de creación del CRM

    payload = {
        "nombre": perfil.get("nombre"),
        "empresa": perfil.get("empresa"),
        "necesidad": perfil.get("necesidad"),
        "presupuesto": perfil.get("presupuesto"),
        "intencion": perfil.get("intencion")
    }

    try:
        response = requests.post(url, headers=HEADERS, json=payload)
        if response.status_code in [200, 201]:
            print("✅ Lead creado exitosamente en el CRM.")
            return response.json()
        else:
            print(f"❌ Error al crear lead: {response.status_code} - {response.text}")
    except requests.exceptions.RequestException as e:
        print(f"🚨 Error de conexión: {e}")

# ===============================
# Buscar lead por nombre (GET)
# ===============================
def buscar_lead(nombre):
    url = f"{CRM_API_BASE_URL}/leads/search?nombre={nombre}"  # Cambiar según tu CRM

    try:
        response = requests.get(url, headers=HEADERS)
        if response.status_code == 200:
            resultados = response.json()
            if resultados:
                print("🔍 Lead existente encontrado.")
                return resultados
            else:
                print("ℹ️ No se encontró ningún lead con ese nombre.")
        else:
            print(f"❌ Error al buscar lead: {response.status_code} - {response.text}")
    except requests.exceptions.RequestException as e:
        print(f"🚨 Error de conexión: {e}")
