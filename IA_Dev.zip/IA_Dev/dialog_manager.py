# ========== dialog_manager.py ===========
from text import extraer_nombre, extraer_empresa, extraer_presupuesto, extraer_intencion

perfil_usuario = {
    "nombre": None,
    "empresa": None,
    "necesidad": None,
    "presupuesto": None,
    "intencion": None
}

def actualizar_perfil(texto, slot_esperado):
    if slot_esperado == "nombre":
        perfil_usuario["nombre"] = extraer_nombre(texto)
    elif slot_esperado == "empresa":
        perfil_usuario["empresa"] = extraer_empresa(texto)
    elif slot_esperado == "necesidad":
        perfil_usuario["necesidad"] = texto
    elif slot_esperado == "presupuesto":
        perfil_usuario["presupuesto"] = extraer_presupuesto(texto)
    elif slot_esperado == "intencion":
        perfil_usuario["intencion"] = extraer_intencion(texto)
    return perfil_usuario

def verificar_slots():
    if not perfil_usuario["nombre"]:
        return "nombre", "¿Podrías decirme tu nombre, por favor?"
    elif not perfil_usuario["empresa"]:
        return "empresa", "¿Para qué empresa trabajas o representas?"
    elif not perfil_usuario["necesidad"]:
        return "necesidad", "¿Qué estás buscando o en qué puedo ayudarte específicamente?"
    elif not perfil_usuario["presupuesto"]:
        return "presupuesto", "¿Con qué presupuesto estimado cuentas para esto?"
    elif not perfil_usuario["intencion"]:
        return "intencion", "¿Cuál es tu interés principal? ¿Quieres comprar, informarte o comparar opciones?"
    else:
        return None, None

def obtener_estado_perfil():
    return perfil_usuario

def reiniciar_perfil():
    for clave in perfil_usuario:
        perfil_usuario[clave] = None

        
