# ============================
# voice_rec.py – Reconocimiento de voz
# ============================
import speech_recognition as sr

def transcribir_audio():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        recognizer.pause_threshold = 1.2
        print("🎤 Hablando... (esperando voz)")
        audio = recognizer.listen(source)
        print("🔝 Audio capturado, procesando...")

    try:
        texto = recognizer.recognize_google(audio, language="es-ES")
        print(f"🗣️ Has dicho: {texto}")
        return texto
    except sr.UnknownValueError:
        print("❌ No se entendió el audio.")
        return None
    except sr.RequestError as e:
        print(f"Error al conectarse a Google Speech: {e}")
        return None